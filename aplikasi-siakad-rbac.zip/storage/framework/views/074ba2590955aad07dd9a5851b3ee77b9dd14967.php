<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="img/logo/logo.png" rel="icon">
    <title>SIAKAD SMP 17 BAUBAU - Login</title>
    <link href="<?php echo e(asset('assets/ruangadmin')); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet"
        type="text/css">
    <link href="<?php echo e(asset('assets/ruangadmin')); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"
        type="text/css">
    <link href="<?php echo e(asset('assets/ruangadmin')); ?>/css/ruang-admin.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-login">
    <!-- Login Content -->
    <div class="container-login">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-12 col-md-9">
                <div class="card shadow-sm my-5 mx-5 px-2 py-2">
                    <div class="card-body p-0 px-4">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="login-form">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">LOGIN <br>SIAKAD SMP 17</h1>
                                    </div>
                                    <div class="row mt-1 mb-1">
                                        <div class="col-sm-12 col-md-12 col-lg-12">
                                            <?php if(session('status')): ?>
                                                <div class="alert alert-success">
                                                    <?php echo e(session('status')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <form class="user" action="<?php echo e(route('post-login')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="cekrequest" value="umum">
                                        <div class="form-group">
                                            <input type="text" name="login_username" class="form-control"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Masukkan username anda...">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="login_password" class="form-control"
                                                id="exampleInputPassword" placeholder="Masukkan password anda...">
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small"
                                                style="line-height: 1.5rem;">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember
                                                    Me</label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-success btn-block">LOGIN</a>
                                        </div>
                                        
                                        
                                    </form>
                                    
                                    
                                    <div class="text-center">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Login Content -->
    <script src="<?php echo e(asset('assets/ruangadmin')); ?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/ruangadmin')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/ruangadmin')); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/ruang-admin.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-siakad-rbac\resources\views/login-siswa.blade.php ENDPATH**/ ?>