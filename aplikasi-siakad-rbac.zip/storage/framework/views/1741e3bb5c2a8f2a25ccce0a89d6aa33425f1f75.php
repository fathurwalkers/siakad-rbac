<?php $__env->startSection('title', 'Dashboard - Daftar Siswa'); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-title', 'Dashboard - Daftar Siswa'); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <h4>
                                    <b>
                                        Daftar Siswa
                                    </b>
                                </h4>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                                <button type="button" class="btn btn-md btn-info" data-toggle="modal"
                                    data-target="#modaltambah">
                                    Tambah Siswa
                                </button>
                            </div>
                        </div>

                        
                        <div class="modal fade" id="modaltambah" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabelLogout">
                                            Tambah Siswa
                                        </h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('tambah-siswa')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">

                                            <div class="row">
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="siswa_nama">Nama Siswa</label>
                                                        <input type="text" class="form-control" id="siswa_nama"
                                                            aria-describedby="emailHelp" placeholder="" name="siswa_nama">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="siswa_nisn">NISN</label>
                                                        <input type="text" class="form-control" id="siswa_nisn"
                                                            aria-describedby="emailHelp" placeholder="" name="siswa_nisn">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="siswa_telepon">No. HP / Telepon</label>
                                                        <input type="text" class="form-control" id="siswa_telepon"
                                                            aria-describedby="emailHelp" placeholder=""
                                                            name="siswa_telepon">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label class="input-group-text" for="siswa_kelas">Kelas</label>
                                                        <select class="form-control" id="siswa_kelas" name="siswa_kelas">
                                                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($kel->id); ?>"><?php echo e($kel->kelas_nama); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                    <img id="output_image" class="border border-1" />
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                    <div class="form-group">
                                                        <label for="exampleFormControlFile1">Foto : </label>
                                                        <input type="file" class="form-control-file"
                                                            onchange="preview_image(event)" name="foto">
                                                        <small class="form-text text-muted">Upload Pas Foto ekstensi
                                                            .jpg</small>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label class="input-group-text" for="siswa_jeniskelamin">Jenis
                                                            Kelamin</label>
                                                        <select class="form-control" id="siswa_jeniskelamin"
                                                            name="siswa_jeniskelamin">
                                                            <option value="L">Laki-Laki</option>
                                                            <option value="P">Perempuan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-6 col-lg-6">
                                                    <div class="form-group">
                                                        <label for="siswa_alamat">Alamat</label>
                                                        <input type="text" class="form-control" id="siswa_alamat"
                                                            aria-describedby="emailHelp"
                                                            placeholder="contoh : Jl. Bakti Abri" name="siswa_alamat">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-info"
                                                data-dismiss="modal">Batalkan</button>
                                            <button type="submit" class="btn btn-success">Tambah</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <hr />
                        <div class="row">
                            <div class="table-responsive">
                                <table id="example" class="display table-bordered" style="width:100%">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama</th>
                                            <th>NISN</th>
                                            <th>Jenis Kelamin</th>
                                            <th>No. Telepon</th>
                                            <th>Status</th>
                                            <th>Kelas</th>
                                            <?php if($users->login_level == 'admin'): ?>
                                            <th>Kelola</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->siswa_nama); ?></td>
                                                <td><?php echo e($item->siswa_nisn); ?></td>
                                                <td>
                                                    <?php switch($item->siswa_jeniskelamin):
                                                        case ('L'): ?>
                                                            Laki - Laki
                                                        <?php break; ?>

                                                        <?php case ('P'): ?>
                                                            Perempuan
                                                        <?php break; ?>
                                                    <?php endswitch; ?>
                                                </td>
                                                <td><?php echo e($item->siswa_telepon); ?></td>
                                                <td><?php echo e($item->siswa_status); ?></td>
                                                <td><?php echo e($item->kelas->kelas_nama); ?></td>

                                                <?php if($users->login_level == 'admin'): ?>
                                                <td>
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                            <button data-toggle="modal"
                                                                data-target="#modallihat<?php echo e($item->id); ?>"
                                                                class="btn btn-sm btn-primary mr-1">Lihat</button>
                                                            <button data-toggle="modal"
                                                                data-target="#modaltambahsiswa<?php echo e($item->id); ?>"
                                                                class="btn btn-sm btn-success mr-1">Ubah</button>
                                                            <button data-toggle="modal"
                                                                data-target="#modalhpus<?php echo e($item->id); ?>"
                                                                class="btn btn-sm btn-danger">Hapus</button>
                                                        </div>
                                                    </div>
                                                </td>
                                                <?php endif; ?>
                                            </tr>

                                            
                                            <div class="modal fade" id="modalhpus<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                Konfirmasi
                                                                Tindakan Penghapusan!</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Apakah anda yakin ingin menghapus Data Siswa
                                                                <?php echo e($item->siswa_nama); ?> ?
                                                            </p>
                                                        </div>
                                                        <div class="modal-footer">

                                                            <form action="<?php echo e(route('hapus-siswa', $item->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="logoutrequest">
                                                                <button type="button" class="btn btn-warning"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-danger">Hapus</button>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            

                                            
                                            <div class="modal fade" id="modaltambahsiswa<?php echo e($item->id); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                Ubah Data Siswa
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?php echo e(route('post-ubah-siswa', $item->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">

                                                                <div class="row">
                                                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="siswa_nama">Nama</label>
                                                                            <input type="text" class="form-control"
                                                                                id="siswa_nama"
                                                                                aria-describedby="emailHelp"
                                                                                name="siswa_nama"
                                                                                value="<?php echo e($item->siswa_nama); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                                                        <div class="form-group">
                                                                            <label for="siswa_telepon">No.
                                                                                Telepon</label>
                                                                            <input type="text" class="form-control"
                                                                                id="siswa_telepon"
                                                                                aria-describedby="emailHelp"
                                                                                name="siswa_telepon"
                                                                                value="<?php echo e($item->siswa_telepon); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-info"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-success">Ubah</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            

                                            
                                            <div class="modal fade" id="modallihat<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                Data Siswa - <?php echo e($item->siswa_nama); ?>

                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row border-1">
                                                                <div
                                                                    class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                                    <img src="<?php echo e(asset('assets')); ?>/<?php echo e($item->siswa_foto); ?>"
                                                                        alt="" width="150px">
                                                                </div>
                                                            </div>
                                                            <br />
                                                            <div class="row">
                                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                                    <p>
                                                                        Nama : <?php echo e($item->siswa_nama); ?> <br>
                                                                        NISN : <?php echo e($item->siswa_nisn); ?> <br>
                                                                        Kelas : <?php echo e($item->kelas->kelas_nama); ?> <br>
                                                                        Jenis Kelamin :
                                                                        <?php switch($item->siswa_jeniskelamin):
                                                                            case ('L'): ?>
                                                                                Laki - Laki
                                                                            <?php break; ?>

                                                                            <?php case ('P'): ?>
                                                                                Perempuan
                                                                            <?php break; ?>
                                                                        <?php endswitch; ?> <br>
                                                                        No. HP / Telepon : <?php echo e($item->siswa_telepon); ?> <br>
                                                                        Alamat : <?php echo e($item->siswa_alamat); ?> <br>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-warning"
                                                                data-dismiss="modal">Batalkan</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-siakad-rbac\resources\views/dashboard/daftar-siswa.blade.php ENDPATH**/ ?>