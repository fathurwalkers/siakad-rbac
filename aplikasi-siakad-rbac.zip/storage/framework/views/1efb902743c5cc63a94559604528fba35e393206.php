<?php $__env->startSection('title', 'Dashboard - Lihat Nilai Siswa'); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-title', 'Dashboard - Lihat Nilai Siswa'); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <h4>
                                <b>
                                    Input Nilai - <?php echo e($matapelajaran->matapelajaran_nama); ?>

                                </b>
                            </h4>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">

                            <form action="<?php echo e(route('post-input-nilai', [$matapelajaran->id, $kelas->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            <div class="table-responsive">

                                <table id="" class="table table-bordered table-fixed" style="">

                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Siswa</th>
                                            <th>Mata Pelajaran</th>
                                            <th>Tugas</th>
                                            <th>Absensi</th>
                                            <th>UTS</th>
                                            <th>UAS</th>
                                            <th>Rata - Rata</th>
                                            <th>Keterangan</th>
                                        </tr>
                                    </thead>

                                    <?php
                                        $sis = 1;
                                        $mat = 1;
                                        $o = 1;
                                        $k = 1;
                                        $tugas = 1;
                                        $absensi = 1;
                                        $uts = 1;
                                        $uas = 1;
                                        $ratarata = 1;
                                        $keterangan = 1;
                                    ?>
                                    <tbody>
                                        <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <input type="hidden" name="increment[<?php echo e($k++); ?>]" value="<?php echo e($o++); ?>">
                                                <input type="hidden" name="iter[<?php echo e($item->id); ?>]" value="<?php echo e($item->id); ?>">

                                                <input type="hidden" name="siswa_id[<?php echo e($sis++); ?>]" value="<?php echo e($item->siswa->id); ?>">

                                                <input type="hidden" name="matapelajaran_id[<?php echo e($mat++); ?>]" value="<?php echo e($item->matapelajaran->id); ?>">

                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>

                                                <td><?php echo e($item->siswa->siswa_nama); ?></td>
                                                <td><?php echo e($item->matapelajaran->matapelajaran_nama); ?></td>

                                                <td>
                                                    <input type="number" min="0" max="100" name="nilai_siswa_tugas[<?php echo e($tugas++); ?>]" placeholder="Nilai Tugas...">
                                                </td>

                                                <td>
                                                    <input type="number" min="0" max="100" name="nilai_siswa_absensi[<?php echo e($absensi++); ?>]" placeholder="Nilai Absensi...">
                                                </td>

                                                <td>
                                                    <input type="number" min="0" max="100" name="nilai_siswa_uts[<?php echo e($uts++); ?>]" placeholder="Nilai UTS...">
                                                </td>

                                                <td>
                                                    <input type="number" min="0" max="100" name="nilai_siswa_uas[<?php echo e($uas++); ?>]" placeholder="Nilai UAS...">
                                                </td>

                                                <td>
                                                    <input type="number" min="0" max="100" name="nilai_siswa_ratarata[<?php echo e($ratarata++); ?>]" placeholder="Nilai Rata - Rata...">
                                                </td>

                                                <td>
                                                    <input type="text" name="nilai_siswa_keterangan[<?php echo e($keterangan++); ?>]" placeholder="Keterangan Nilai...">
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>

                            </div>

                            <div class="row my-3">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <button type="submit" class="btn btn-md btn-info">PROSES</button>
                                </div>
                            </div>

                            </form>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-siakad-rbac\resources\views/dashboard/input-nilai.blade.php ENDPATH**/ ?>