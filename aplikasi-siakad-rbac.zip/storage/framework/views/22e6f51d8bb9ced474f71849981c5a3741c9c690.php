<div>
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
            <div class="sidebar-brand-icon">
                <img src="<?php echo e(asset('assets/ruangadmin')); ?>/img/logo/logo2.png">
            </div>
            <div class="sidebar-brand-text mx-3">SIAKAD SMP</div>
        </a>
        <hr class="sidebar-divider my-0">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>

        <!-- ----------------------- MENU KELOLA ----------------------- -->
        <hr class="sidebar-divider">
        <div class="sidebar-heading">
            Menu Kelola
        </div>

        

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm1"
                aria-expanded="true" aria-controls="collapseForm1">
                <i class="fab fa-fw fa-wpforms"></i>
                <span>Kelas</span>
            </a>
            <div id="collapseForm1" class="collapse" aria-labelledby="headingForm" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Kelola Kelas</h6>
                    <a class="collapse-item" href="<?php echo e(route('daftar-kelas')); ?>">Daftar Kelas</a>
                    
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm"
                aria-expanded="true" aria-controls="collapseForm">
                <i class="fab fa-fw fa-wpforms"></i>
                <span>Mata Pelajaran</span>
            </a>
            <div id="collapseForm" class="collapse" aria-labelledby="headingForm" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Kelola Mata Pelajaran</h6>
                    <a class="collapse-item" href="<?php echo e(route('daftar-matapelajaran')); ?>">Daftar Mata Pelajaran</a>
                    
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm2"
                aria-expanded="true" aria-controls="collapseForm2">
                <i class="fab fa-fw fa-wpforms"></i>
                <span>Kelola Nilai</span>
            </a>
            <div id="collapseForm2" class="collapse" aria-labelledby="headingForm" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Manajemen Nilai</h6>
                    <a class="collapse-item" href="<?php echo e(route('daftar-nilai')); ?>">Daftar Nilai</a>
                    
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm24"
                aria-expanded="true" aria-controls="collapseForm24">
                <i class="fab fa-fw fa-wpforms"></i>
                <span>Kelola Absen</span>
            </a>
            <div id="collapseForm24" class="collapse" aria-labelledby="headingForm" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Manajemen Absen</h6>
                    <a class="collapse-item" href="<?php echo e(route('daftar-absen')); ?>">Daftar Absen</a>
                    
                </div>
            </div>
        </li>

        
        <!-- ----------------------- END MENU KELOLA ----------------------- -->

        <!-- ----------------------- KELOLA LAINNYA ----------------------- -->
        <hr class="sidebar-divider">
        <div class="sidebar-heading">
            Menu Lainnya
        </div>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage"
                aria-expanded="true" aria-controls="collapsePage">
                <i class="fas fa-fw fa-columns"></i>
                <span>Kelola Pengguna</span>
            </a>
            <div id="collapsePage" class="collapse" aria-labelledby="headingPage"
                data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Manajemen Pengguna</h6>
                    <a class="collapse-item" href="<?php echo e(route('daftar-siswa')); ?>">Daftar Siswa</a>
                    <a class="collapse-item" href="<?php echo e(route('daftar-guru')); ?>">Daftar Guru</a>
                </div>
            </div>
        </li>
        
        <!-- ----------------------- END KELOLA LAINNYA ----------------------- -->


        <hr class="sidebar-divider">
        <div class="version" id="version-ruangadmin"></div>
    </ul>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-siakad-rbac\resources\views/components/dashboard-sidebar.blade.php ENDPATH**/ ?>