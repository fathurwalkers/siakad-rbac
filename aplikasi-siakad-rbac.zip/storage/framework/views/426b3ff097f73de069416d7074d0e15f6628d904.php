<?php $__env->startSection('title', 'Dashboard - Daftar Nilai'); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-title', 'Dashboard - Daftar Nilai'); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <h4>
                                <b>
                                    Daftar Nilai - <?php echo e($matapelajaran->matapelajaran_nama); ?>

                                </b>
                            </h4>
                        </div>
                        <div class="row">
                            <div class="table-responsive">
                                <table id="example" class="display table-bordered" style="width:100%">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Siswa</th>
                                            <th>Mata Pelajaran</th>
                                            <th>Tugas</th>
                                            <th>Absensi</th>
                                            <th>UTS</th>
                                            <th>UAS</th>
                                            <th>Rata - Rata</th>
                                            <th>Keterangan</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>

                                                <td><?php echo e($item->siswa->siswa_nama); ?></td>
                                                <td><?php echo e($item->matapelajaran->matapelajaran_nama); ?></td>

                                                <?php if($item->nilai_siswa_tugas == NULL): ?>
                                                    <td>Kosong</td>
                                                <?php else: ?>
                                                <td><?php echo e($item->nilai_siswa_tugas); ?></td>
                                                <?php endif; ?>

                                                <?php if($item->nilai_siswa_absensi == NULL): ?>
                                                    <td>Kosong</td>
                                                <?php else: ?>
                                                <td><?php echo e($item->nilai_siswa_absensi); ?></td>
                                                <?php endif; ?>

                                                <?php if($item->nilai_siswa_uts == NULL): ?>
                                                    <td>Kosong</td>
                                                <?php else: ?>
                                                <td><?php echo e($item->nilai_siswa_uts); ?></td>
                                                <?php endif; ?>

                                                <?php if($item->nilai_siswa_uas == NULL): ?>
                                                    <td>Kosong</td>
                                                <?php else: ?>
                                                <td><?php echo e($item->nilai_siswa_uas); ?></td>
                                                <?php endif; ?>

                                                <?php if($item->nilai_ratarata == NULL): ?>
                                                    <td>Kosong</td>
                                                <?php else: ?>
                                                <td><?php echo e($item->nilai_ratarata); ?></td>
                                                <?php endif; ?>

                                                <?php if($item->nilai_keterangan == NULL): ?>
                                                    <td>Kosong</td>
                                                <?php else: ?>
                                                <td><?php echo e($item->nilai_keterangan); ?></td>
                                                <?php endif; ?>

                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-siakad-rbac\resources\views/dashboard/lihat-nilai-matapelajaran.blade.php ENDPATH**/ ?>