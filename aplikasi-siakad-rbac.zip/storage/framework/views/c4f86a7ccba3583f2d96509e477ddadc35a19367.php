<?php $__env->startSection('title', 'Dashboard - Input Nilai - Pilih Matapelajaran '); ?>

<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-title', 'Dashboard - Input Nilai - Pilih Matapelajaran '); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="container">
                        <div class="row">

                            <div class="col-sm-6 col-md-6 col-lg-6">
                                <h4>
                                    <b>
                                        Input Nilai - Pilih Matapelajaran
                                    </b>
                                </h4>
                            </div>

                        </div>
                        <hr />
                        <div class="row">
                            <div class="table-responsive">
                                <table id="example" class="display table-bordered" style="width:100%">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No.</th>
                                            <th>Mata Pelajaran</th>
                                            <th>Kode Mata Pelajaran</th>

                                            <th>Kelola</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $matapelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->matapelajaran_nama); ?></td>
                                                <td><?php echo e($item->matapelajaran_kode); ?></td>

                                                <td>
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                                                                <button onclick="location.href = '<?php echo e(route('input-nilai', [$item->id, $kelas->id])); ?>';"
                                                                        class="btn btn-sm btn-primary mr-1">Input Nilai</button>
                                                        </div>
                                                    </div>
                                                </td>

                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-siakad-rbac\resources\views/dashboard/input-nilai-matapelajaran.blade.php ENDPATH**/ ?>